package com.eb.Entity;

public class Login {
	
	private String userId;
	private String mobile;

}
