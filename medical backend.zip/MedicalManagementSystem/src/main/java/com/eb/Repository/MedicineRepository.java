package com.eb.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eb.Entity.Medicine;

public interface MedicineRepository extends JpaRepository<Medicine, Long> {
    
}

